# Hacked together by Simon Shelston - simon@splunk.com
#
# ___ NOTES ___
# Use --debug switch to run in debug mode which will write to stdout and not to file
# Use an integer as a switch to have the script support multiple instances of itself. Make sure to have
# the monitor:// stanza changed to the _n log name!
#

import time, datetime, os, sys, random

HOME_PATH = "."
filename = "noise_apache.log"
debug = False

# Check for arguments
for arg in sys.argv:
	if (arg == "--debug"):
		debug = True

	if (arg.isdigit()):
		filename = str.replace(filename, ".log", "_" + str(arg) + ".log")

# Kill file if it exists.
if(debug == False):
	theFile = open(HOME_PATH + '/' + filename, 'w')

# Define lib path
libPath = os.path.join(HOME_PATH, 'data')

# List of External IP addresses
clientipAddresses = open(os.path.join(libPath, 'external_ips.txt')).readlines()

# List of a goodly number of user agents - we pick one at random when we "login"
useragents = open(os.path.join(libPath, 'user_agents.txt')).readlines()


# Neverending Loop
loop = 1

while loop :

	# Append to file
	theFile = open(HOME_PATH + '/' + filename, 'a')

	# Define Data
	#############

	currentTime = datetime.datetime.now()
	baseUrl = "http://shop.gourmet-shop.com"

	# Client IP Addresses
	clientipAddress = clientipAddresses[random.randint(0,len(clientipAddresses)-1)].replace("\n","")

	# Product Ids
	productIds = ["FI-FW-02","RP-SN-01","FI-SW-01","AV-SB-02", "AV-CB-01","FL-DSH-01","K9-BD-01","K9-CW-01","FL-DLH-02","FI-FW-02","RP-SN-01","FI-SW-01","RP-LI-02"]
	productId = productIds[random.randint(0, len(productIds) - 1)]

	# Item Ids
	itemIds = ["EST-19","EST-18","EST-14","EST-6","EST-26","EST-17","EST-16","EST-15","EST-27","EST-7","EST-21","EST-11","EST-12","EST-13","EST-20","EST-1"]
	itemId = itemIds[random.randint(0, len(itemIds) - 1)]

	# Category Ids
	catIds = ["CAVIAR","CHEESE","TRUFFLES","TRUFFLES","CONDIMENTS","BAKING"]
	catId = catIds[random.randint(0, len(catIds) - 1)]

	# JSESSION Ids
	jsessionId = "SD" + str(random.randint(1, 10)) + "SL" + str(random.randint(1, 10)) + "FF" + str(random.randint(1, 10)) + "ADFF" + str(random.randint(1, 10))

	# Actions
	actions = ["purchase", "addtocart", "remove", "view", "changequantity"]
	action = actions[random.randint(0, len(actions) - 1)]

	# Status
	statuses = ["200","200","200","200","200","200","200","200","200","200","200", "400", "406", "404","503","503"]
	status = statuses[random.randint(0, len(statuses) - 1)]

	# Method
	methods = ["GET", "GET", "GET", "GET", "POST"]
	method = methods[random.randint(0, len(methods) - 1)]

	# userId
	userIds = ["hong", "kim", "lee", "park", "kwon", "choi", "shin", "seo", "lim", "kwak"]
	userId = userIds[random.randint(0, len(userIds) - 1)]

	# Bytes Transferred
	bytesXferred = str(random.randint(200,4000))

	# Time Taken
	timeTaken =  str(random.randint(100,1000))

	uris = [
	"/cart.do?action=" + action + "&itemId=" + itemId + "&product_id=" + productId,
	"/product.screen?product_id=" + productId,
	"/category.screen?category_id=" + catId,
	"/cart.do?action=" + action + "&itemId=" + itemId + "&product_id=" + productId,
	"/product.screen?product_id=" + productId,
	"/category.screen?category_id=" + catId,
	"/cart.do?action=" + action + "&itemId=" + itemId + "&product_id=" + productId,
	"/product.screen?product_id=" + productId,
	"/category.screen?category_id=" + catId,
	"/oldlink?item_id=" + itemId
	]
	uri = uris[random.randint(0, len(uris) - 1)] + "&JSESSIONID=" + jsessionId
	referralUri = baseUrl

	useragents = [
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)",
	"Opera/9.01 (Windows NT 5.1; U; en)",
	"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.38 Safari/533.4",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)",
	"Googlebot/2.1 ( http://www.googlebot.com/bot.html) ",
	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)",
	"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6",
	"Opera/9.20 (Windows NT 6.0; U; en)"
	]

	#loggedInUsers[user_to_login]['userAgent'] = user_agents[random.randint(0,len(user_agents)-1)].replace("\n","")
	useragent = useragents[random.randint(0, len(useragents) - 1)]

	# Random Millisecond
	randMs = random.randint(1, 100) + 100

	if(clientipAddress == "10.2.1.44" and status == "503"):
		continue

	line = clientipAddress + " - " + userId + " [" + datetime.datetime.now().strftime('%d/%b/%Y:%H:%M:%S:') + str(randMs) + " +0900] \"" + method + " " + uri + " HTTP/1.1\" " + status + " " + bytesXferred + "\n"

	if(debug):
		print(line),
	else:
		theFile.write(line)

	time.sleep(random.random())

	# This ensures proper line breaking for solid tailing
	theFile.close()
