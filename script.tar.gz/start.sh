#!/usr/bin/env bash
kill -9 `ps -ef | grep spark2-thriftserver | awk '{print $2}'`

export SPARK_MAJOR_VERSION=2

spark-shell --master local[*]
