import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object WeblogCounter {
  def main(args: Array[String]) {
    val conf = new SparkConf()
      .setAppName("Web Log Counter")

    val sc = new SparkContext(conf)

    sc.stop()
  }
}
