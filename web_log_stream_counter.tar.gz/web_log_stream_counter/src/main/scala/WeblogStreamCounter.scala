import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer

import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

object WeblogStreamCounter {
  def main(args: Array[String]) {
    val conf = new SparkConf()
      .setAppName("Web Log Stream Counter")

    val sc = new SparkContext(conf)
    sc.setLogLevel("INFO")

    val ssc = new StreamingContext(sc, Seconds(5))

    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "sk",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (true: java.lang.Boolean))

    val topics = Array("weblog")

    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      Subscribe[String, String](topics, kafkaParams))

    val weblog = stream.map(record => record.value)

    val itemName = sc.textFile("item.txt")
      .map(line => line.split(','))
      .map(fields => (fields(0), fields(1)))

    val purchaseCnt = weblog.transform(rdd => {
      rdd.filter(line => line.contains("action=purchase"))
        .map(line => line.split("&")(1))
        .map(line => (line.split("=")(1), 1))
        .reduceByKey((v1, v2) => v1 + v2)
    })

    purchaseCnt.foreachRDD(rdd => {
      val result = itemName.join(rdd).values
      result.collect.foreach(println)
    })

    ssc.start()

    ssc.awaitTermination()
  }
}
